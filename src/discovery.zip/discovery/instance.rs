//! 服务实例定义
//!
//! 参照 volo 的设计，定义服务实例和变化通知

use serde::{Deserialize, Deserializer, Serialize, Serializer};
use std::borrow::Cow;
use std::collections::HashMap;
use std::sync::Arc;

/// 服务实例
///
/// 包含服务实例的完整信息，包括地址、权重、标签、版本等
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Instance {
    /// 服务实例地址（格式：host:port）
    pub address: String,
    /// 服务实例权重（用于负载均衡）
    pub weight: u32,
    /// 服务实例标签（元数据）
    #[serde(with = "tags_serde")]
    pub tags: HashMap<Cow<'static, str>, Cow<'static, str>>,
    /// 服务类型（如 "signaling-online", "message-orchestrator"）
    pub service_type: String,
    /// 服务实例ID（唯一标识）
    pub instance_id: String,
    /// 服务版本（可选，用于版本路由和灰度发布）
    #[serde(default)]
    pub version: Option<String>,
    /// 服务实例是否健康
    pub healthy: bool,
    /// 最后健康检查时间（不序列化）
    #[serde(skip)]
    pub last_health_check: Option<std::time::Instant>,
}

impl Instance {
    /// 创建新的服务实例
    pub fn new(
        address: String,
        service_type: String,
        instance_id: String,
    ) -> Self {
        Self {
            address,
            weight: 1,
            tags: HashMap::new(),
            service_type,
            instance_id,
            version: None,
            healthy: true,
            last_health_check: Some(std::time::Instant::now()),
        }
    }

    /// 创建带版本的服务实例
    pub fn new_with_version(
        address: String,
        service_type: String,
        instance_id: String,
        version: String,
    ) -> Self {
        Self {
            address,
            weight: 1,
            tags: HashMap::new(),
            service_type,
            instance_id,
            version: Some(version),
            healthy: true,
            last_health_check: Some(std::time::Instant::now()),
        }
    }

    /// 设置权重
    pub fn with_weight(mut self, weight: u32) -> Self {
        self.weight = weight;
        self
    }

    /// 设置版本
    pub fn with_version(mut self, version: String) -> Self {
        self.version = Some(version);
        self
    }

    /// 设置标签
    pub fn with_tag(mut self, key: Cow<'static, str>, value: Cow<'static, str>) -> Self {
        self.tags.insert(key, value);
        self
    }

    /// 批量设置标签
    pub fn with_tags(mut self, tags: HashMap<Cow<'static, str>, Cow<'static, str>>) -> Self {
        self.tags.extend(tags);
        self
    }

    /// 获取服务地址（格式：http://address:port）
    pub fn http_address(&self) -> String {
        format!("http://{}", self.address)
    }

    /// 更新健康状态
    pub fn update_health(&mut self, healthy: bool) {
        self.healthy = healthy;
        self.last_health_check = Some(std::time::Instant::now());
    }
}

/// 服务实例变化通知
///
/// 用于通知服务实例的变化（新增、更新、删除）
#[derive(Debug, Clone)]
pub struct InstanceChange {
    /// 服务类型
    pub service_type: String,
    /// 所有实例（变化后）
    pub all: Vec<Arc<Instance>>,
    /// 新增的实例
    pub added: Vec<Arc<Instance>>,
    /// 更新的实例
    pub updated: Vec<Arc<Instance>>,
    /// 删除的实例
    pub removed: Vec<Arc<Instance>>,
}

impl InstanceChange {
    /// 创建变化通知
    pub fn new(service_type: String) -> Self {
        Self {
            service_type,
            all: Vec::new(),
            added: Vec::new(),
            updated: Vec::new(),
            removed: Vec::new(),
        }
    }

    /// 检查是否有变化
    pub fn has_changes(&self) -> bool {
        !self.added.is_empty() || !self.updated.is_empty() || !self.removed.is_empty()
    }
}

/// 计算两个实例列表的差异
pub fn diff_instances(
    service_type: String,
    prev: Vec<Arc<Instance>>,
    next: Vec<Arc<Instance>>,
) -> InstanceChange {
    let mut added = Vec::new();
    let mut updated = Vec::new();
    let mut removed = Vec::new();

    // 创建实例ID到实例的映射
    let prev_map: HashMap<_, _> = prev.iter().map(|i| (i.instance_id.clone(), i.clone())).collect();
    let next_map: HashMap<_, _> = next.iter().map(|i| (i.instance_id.clone(), i.clone())).collect();

    // 找出新增和更新的实例
    for instance in &next {
        if let Some(prev_instance) = prev_map.get(&instance.instance_id) {
            // 检查是否有更新（地址、权重、标签、版本、健康状态）
            if prev_instance.address != instance.address
                || prev_instance.weight != instance.weight
                || prev_instance.tags != instance.tags
                || prev_instance.version != instance.version
                || prev_instance.healthy != instance.healthy
            {
                updated.push(instance.clone());
            }
        } else {
            added.push(instance.clone());
        }
    }

    // 找出删除的实例
    for instance in &prev {
        if !next_map.contains_key(&instance.instance_id) {
            removed.push(instance.clone());
        }
    }

    InstanceChange {
        service_type,
        all: next,
        added,
        updated,
        removed,
    }
}

// 为 HashMap<Cow<'static, str>, Cow<'static, str>> 提供序列化支持
mod tags_serde {
    use serde::{Deserialize, Deserializer, Serialize, Serializer};
    use std::borrow::Cow;
    use std::collections::HashMap;

    pub fn serialize<S>(
        tags: &HashMap<Cow<'static, str>, Cow<'static, str>>,
        serializer: S,
    ) -> Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        let map: HashMap<&str, &str> = tags.iter().map(|(k, v)| (k.as_ref(), v.as_ref())).collect();
        map.serialize(serializer)
    }

    pub fn deserialize<'de, D>(
        deserializer: D,
    ) -> Result<HashMap<Cow<'static, str>, Cow<'static, str>>, D::Error>
    where
        D: Deserializer<'de>,
    {
        let map: HashMap<String, String> = HashMap::deserialize(deserializer)?;
        Ok(map.into_iter().map(|(k, v)| (Cow::Owned(k), Cow::Owned(v))).collect())
    }
}
