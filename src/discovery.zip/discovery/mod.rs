//! 服务注册发现模块
//!
//! 参照 volo 的设计理念，提供统一的服务注册发现接口
//! 支持自动健康检查、服务变化监听、多种后端实现
//!
//! ## 模块结构
//!
//! - `backend/` - 后端实现（etcd、Consul、Service Mesh）
//! - `instance.rs` - 服务实例定义
//! - `registry.rs` - Registry 核心实现
//! - `watcher.rs` - 服务变化监听
//! - `client.rs` - 全局客户端便捷接口（单例模式）

pub mod backend;
pub mod instance;
pub mod registry;
pub mod watcher;
pub mod client;
#[cfg(feature = "tower")]
pub mod tower;

pub use backend::{Backend, BackendBuilder, BackendType};
pub use instance::{Instance, InstanceChange};
pub use registry::{LoadBalanceStrategy, Registry, RegistryBuilder};
pub use watcher::{Watcher, WatchEvent};
pub use client::{
    discover_service, get_service_registry, init_service_registry, is_initialized,
    parse_load_balance_strategy, register_instance, register_service,
    resolve_service_address, resolve_service_instance, unregister_instance, watch_service,
};
