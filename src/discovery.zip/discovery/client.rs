//! 服务注册发现客户端便捷接口
//!
//! 提供全局单例模式的服务注册发现客户端，简化使用

use crate::discovery::{Instance, Registry, RegistryBuilder, LoadBalanceStrategy};
use crate::config::RegistryConfig;
use std::sync::Arc;
use tokio::sync::OnceCell;

/// 全局服务注册发现实例
static SERVICE_REGISTRY: OnceCell<Arc<Registry>> = OnceCell::const_new();

/// 初始化状态
static INITIALIZED: OnceCell<bool> = OnceCell::const_new();

/// 初始化服务注册发现
///
/// # 参数
/// * `registry_config` - 注册中心配置
/// * `load_balance_strategy` - 负载均衡策略（默认：从配置读取或一致性哈希）
///
/// # 返回
/// 返回 Registry 实例
///
/// # 示例
/// ```rust
/// use flare_server_core::discovery::init_service_registry;
/// use flare_server_core::{RegistryConfig, LoadBalanceStrategy};
///
/// let config = RegistryConfig {
///     registry_type: "etcd".to_string(),
///     endpoints: vec!["http://localhost:2379".to_string()],
///     namespace: "flare".to_string(),
///     ttl: 30,
///     load_balance_strategy: "consistent_hash".to_string(),
/// };
///
/// let registry = init_service_registry(config, None).await?;
/// ```
pub async fn init_service_registry(
    registry_config: RegistryConfig,
    load_balance_strategy: Option<LoadBalanceStrategy>,
) -> Result<Registry, Box<dyn std::error::Error>> {
    // 确保只初始化一次
    if INITIALIZED.get().is_some() {
        return Err("Service registry already initialized".into());
    }

    // 从配置中读取负载均衡策略，或使用传入的参数
    let strategy = load_balance_strategy
        .or_else(|| parse_load_balance_strategy(&registry_config.load_balance_strategy))
        .unwrap_or(LoadBalanceStrategy::ConsistentHash);

    let registry = RegistryBuilder::new()
        .with_config(registry_config.clone())
        .with_load_balance_strategy(strategy)
        .build()
        .await?;

    // 保存到全局实例
    let registry_arc = Arc::new(registry);
    SERVICE_REGISTRY
        .set(registry_arc.clone())
        .map_err(|_| "Service registry already initialized")?;

    INITIALIZED.set(true).map_err(|_| "Already initialized")?;

    tracing::info!(
        "Service registry initialized: type={:?}, load_balance={:?}",
        registry_config.registry_type,
        registry_config.load_balance_strategy
    );

    Ok((*registry_arc).clone())
}

/// 获取全局服务注册发现实例
///
/// # 返回
/// 如果已初始化，返回 Registry 实例，否则返回 None
pub fn get_service_registry() -> Option<Arc<Registry>> {
    SERVICE_REGISTRY.get().cloned()
}

/// 检查是否已初始化
pub fn is_initialized() -> bool {
    INITIALIZED.get().is_some()
}

/// 解析服务地址
///
/// # 参数
/// * `service_type` - 服务类型（如 "signaling-online", "message-orchestrator"）
/// * `key` - 可选的一致性哈希键（用于负载均衡）
/// * `version` - 可选的服务版本（用于版本过滤）
///
/// # 返回
/// 返回服务地址，格式：`http://address:port`
pub async fn resolve_service_address(
    service_type: &str,
    key: Option<&str>,
    version: Option<&str>,
) -> Result<String, Box<dyn std::error::Error>> {
    let registry = get_service_registry()
        .ok_or("Service registry not initialized")?;
    
    registry.get_service_address(service_type, key, false, version)
        .await?
        .ok_or_else(|| format!("Service {} not found", service_type).into())
}

/// 解析服务实例
///
/// # 参数
/// * `service_type` - 服务类型
/// * `key` - 可选的一致性哈希键
/// * `version` - 可选的服务版本（用于版本过滤）
///
/// # 返回
/// 返回 Instance
pub async fn resolve_service_instance(
    service_type: &str,
    key: Option<&str>,
    version: Option<&str>,
) -> Result<Instance, Box<dyn std::error::Error>> {
    let registry = get_service_registry()
        .ok_or("Service registry not initialized")?;
    
    registry.select_instance(service_type, key, false, version)
        .await?
        .ok_or_else(|| format!("Service {} not found", service_type).into())
        .map(|i| (*i).clone())
}

/// 发现服务（获取所有实例）
///
/// # 参数
/// * `service_type` - 服务类型
/// * `include_unhealthy` - 是否包含不健康的实例
/// * `version` - 可选的服务版本（用于版本过滤）
///
/// # 返回
/// 返回所有服务实例列表
pub async fn discover_service(
    service_type: &str,
    include_unhealthy: bool,
    version: Option<&str>,
) -> Result<Vec<Instance>, Box<dyn std::error::Error>> {
    let registry = get_service_registry()
        .ok_or("Service registry not initialized")?;
    
    let instances = registry.discover(service_type, include_unhealthy, version).await?;
    Ok(instances.into_iter().map(|i| (*i).clone()).collect())
}

/// 注册服务实例
///
/// # 参数
/// * `instance` - 服务实例
pub async fn register_instance(
    instance: Instance,
) -> Result<(), Box<dyn std::error::Error>> {
    let registry = get_service_registry()
        .ok_or("Service registry not initialized")?;
    
    registry.register(Arc::new(instance)).await
}

/// 注册服务到注册中心（便捷函数）
///
/// 从 `Config` 自动创建 `Instance` 并注册到注册中心
///
/// # 参数
/// * `config` - 服务配置
/// * `service_type` - 服务类型（如 "signaling-online", "message-orchestrator"）
///
/// # 返回
/// 返回 Registry 实例（如果配置了注册发现），否则返回 None
pub async fn register_service(
    config: &crate::config::Config,
    service_type: &str,
    version: Option<&str>,
) -> Result<Option<Arc<Registry>>, Box<dyn std::error::Error>> {
    if let Some(reg_config) = &config.registry {
        // 如果全局 Registry 已初始化，直接使用
        if let Some(registry) = get_service_registry() {
            let instance = if let Some(version) = version {
                Instance::new_with_version(
                    format!("{}:{}", config.server.address, config.server.port),
                    service_type.to_string(),
                    uuid::Uuid::new_v4().to_string(),
                    version.to_string(),
                )
            } else {
                Instance::new(
                    format!("{}:{}", config.server.address, config.server.port),
                    service_type.to_string(),
                    uuid::Uuid::new_v4().to_string(),
                )
            };

            registry.register(Arc::new(instance.clone())).await?;

            tracing::info!(
                "Service registered: {} at {} (version: {})",
                service_type,
                instance.address,
                instance.version.as_deref().unwrap_or("default")
            );

            return Ok(Some(registry));
        }

        // 否则创建新的 Registry 实例
        let registry = RegistryBuilder::new()
            .with_config(reg_config.clone())
            .build()
            .await?;

        let instance = if let Some(version) = version {
            Instance::new_with_version(
                format!("{}:{}", config.server.address, config.server.port),
                service_type.to_string(),
                uuid::Uuid::new_v4().to_string(),
                version.to_string(),
            )
        } else {
            Instance::new(
                format!("{}:{}", config.server.address, config.server.port),
                service_type.to_string(),
                uuid::Uuid::new_v4().to_string(),
            )
        };

        let registry_arc = Arc::new(registry);
        registry_arc.register(Arc::new(instance.clone())).await?;

        tracing::info!(
            "Service registered: {} at {} (version: {})",
            service_type,
            instance.address,
            instance.version.as_deref().unwrap_or("default")
        );

        Ok(Some(registry_arc))
    } else {
        tracing::info!("Service registry not configured, skipping registration");
        Ok(None)
    }
}

/// 注销服务实例
///
/// # 参数
/// * `instance_id` - 服务实例ID
pub async fn unregister_instance(
    instance_id: &str,
) -> Result<(), Box<dyn std::error::Error>> {
    let registry = get_service_registry()
        .ok_or("Service registry not initialized")?;
    
    registry.unregister(instance_id).await
}

/// 监听服务变化
///
/// # 参数
/// * `service_type` - 服务类型
///
/// # 返回
/// 返回 Watcher，可以用于接收服务变化通知
pub async fn watch_service(
    service_type: &str,
) -> Result<crate::discovery::Watcher, Box<dyn std::error::Error>> {
    let registry = get_service_registry()
        .ok_or("Service registry not initialized")?;
    
    registry.watch(service_type).await
}

/// 解析负载均衡策略字符串
pub fn parse_load_balance_strategy(s: &str) -> Option<LoadBalanceStrategy> {
    match s.to_lowercase().as_str() {
        "round_robin" | "round-robin" => Some(LoadBalanceStrategy::RoundRobin),
        "random" => Some(LoadBalanceStrategy::Random),
        "consistent_hash" | "consistent-hash" => Some(LoadBalanceStrategy::ConsistentHash),
        "least_connections" | "least-connections" => Some(LoadBalanceStrategy::LeastConnections),
        _ => None,
    }
}

