//! Tower Discover 适配器
//!
//! 将 Backend 的 discover 方法与 Tower 的 Discover trait 集成
//! 支持使用 tower::balance::p2c 等负载均衡器
//!
//! ## 架构设计
//!
//! 1. **BackendDiscover**: 实现 Tower 的 `Discover` trait，将 Backend 的 `discover` 方法适配为 Tower 的发现机制
//! 2. **WatcherStream**: 基于 Watcher 的 Stream 实现，用于推送服务变化
//! 3. **create_balanced_channel**: 便捷函数，创建使用 p2c 负载均衡的 Channel

use crate::discovery::backend::Backend;
use crate::discovery::instance::Instance;
use crate::discovery::watcher::Watcher;
use std::collections::HashMap;
use std::pin::Pin;
use std::sync::Arc;
use std::task::{Context, Poll};
use tokio::sync::RwLock;
use tonic::transport::{Channel, Endpoint};
use tower::discover::{Change, Discover};
use tracing::{debug, error, info, warn};

/// Tower Discover 适配器
///
/// 将 Backend 的 discover 方法适配到 Tower 的 Discover trait
/// 支持自动服务发现和动态更新
///
/// ## 使用示例
///
/// ```rust,no_run
/// use flare_server_core::discovery::tower::BackendDiscover;
/// use flare_server_core::discovery::backend::Backend;
/// use tower::balance::p2c::Balance;
/// use std::sync::Arc;
/// use tokio::sync::RwLock;
///
/// # async fn example() -> Result<(), Box<dyn std::error::Error>> {
/// let backend: Arc<RwLock<Box<dyn Backend>>> = ...;
/// let mut discover = BackendDiscover::new(backend, "message-orchestrator".to_string(), None);
///
/// // 执行初始发现
/// discover.initial_discover().await?;
///
/// // 使用 p2c 负载均衡器
/// let balancer = Balance::new(discover);
/// # Ok(())
/// # }
/// ```
pub struct BackendDiscover {
    /// 后端实现
    backend: Arc<RwLock<Box<dyn Backend>>>,
    /// 服务类型
    service_type: String,
    /// 当前已知的服务实例（Key: instance_id, Value: Endpoint）
    instances: Arc<RwLock<HashMap<String, Endpoint>>>,
    /// Watcher 用于监听服务变化
    watcher: Option<Watcher>,
    /// 变化通知通道的接收端
    change_receiver: Option<tokio::sync::mpsc::UnboundedReceiver<Change<String, Endpoint>>>,
    /// 刷新间隔（秒）
    refresh_interval: u64,
}

impl BackendDiscover {
    /// 创建新的 BackendDiscover 实例
    ///
    /// # 参数
    /// * `backend` - 后端实现
    /// * `service_type` - 服务类型（如 "message-orchestrator"）
    /// * `refresh_interval` - 刷新间隔（秒），默认 30 秒
    pub fn new(
        backend: Arc<RwLock<Box<dyn Backend>>>,
        service_type: String,
        refresh_interval: Option<u64>,
    ) -> Self {
        let instances = Arc::new(RwLock::new(HashMap::new()));
        let refresh_interval = refresh_interval.unwrap_or(30);

        // 创建变化通知通道（当前未使用，保留用于未来扩展）
        let (_tx, rx) = tokio::sync::mpsc::unbounded_channel();

        Self {
            backend,
            service_type,
            instances,
            watcher: None,
            change_receiver: Some(rx),
            refresh_interval,
        }
    }

    /// 执行初始发现
    pub async fn initial_discover(&mut self) -> Result<(), Box<dyn std::error::Error>> {
        let backend_guard = self.backend.read().await;
        let discovered_instances = backend_guard.discover(&self.service_type).await?;
        drop(backend_guard);

        {
            let mut current_instances = self.instances.write().await;

            // 处理新发现的实例
            for instance in &discovered_instances {
                // 如果实例已存在，跳过
                if current_instances.contains_key(&instance.instance_id) {
                    continue;
                }

                // 创建新的 Endpoint
                match Self::instance_to_endpoint(instance) {
                    Ok(endpoint) => {
                        current_instances.insert(instance.instance_id.clone(), endpoint.clone());

                        info!(
                            service_type = %self.service_type,
                            instance_id = %instance.instance_id,
                            address = %instance.address,
                            "Discovered new service instance"
                        );
                    }
                    Err(e) => {
                        warn!(
                            service_type = %self.service_type,
                            instance_id = %instance.instance_id,
                            error = %e,
                            "Failed to create endpoint for instance"
                        );
                    }
                }
            }
        } // 释放写锁

        // 启动 Watcher 监听服务变化（在锁外调用）
        self.start_watcher().await?;

        Ok(())
    }

    /// 启动 Watcher 监听服务变化
    async fn start_watcher(&mut self) -> Result<(), Box<dyn std::error::Error>> {
        // 注意：这里需要从 Registry 获取 Watcher
        // 为了简化，我们使用轮询机制
        // 在实际使用中，应该使用 Registry 的 watch_service 方法

        let backend = self.backend.clone();
        let service_type = self.service_type.clone();
        let instances = self.instances.clone();
        let refresh_interval = self.refresh_interval;

        // 启动后台刷新任务
        tokio::spawn(async move {
            let mut interval = tokio::time::interval(tokio::time::Duration::from_secs(refresh_interval));
            interval.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);

            loop {
                interval.tick().await;

                match Self::refresh_instances(&backend, &service_type, &instances).await {
                    Ok(_) => {
                        debug!(
                            service_type = %service_type,
                            "Refreshed service instances"
                        );
                    }
                    Err(e) => {
                        error!(
                            service_type = %service_type,
                            error = %e,
                            "Failed to refresh service instances"
                        );
                    }
                }
            }
        });

        Ok(())
    }

    /// 刷新服务实例
    async fn refresh_instances(
        backend: &Arc<RwLock<Box<dyn Backend>>>,
        service_type: &str,
        instances: &Arc<RwLock<HashMap<String, Endpoint>>>,
    ) -> Result<(), Box<dyn std::error::Error>> {
        let backend_guard = backend.read().await;
        let discovered_instances = backend_guard.discover(service_type).await?;
        drop(backend_guard);

        let mut current_instances = instances.write().await;
        let mut new_instance_ids = std::collections::HashSet::new();

        // 处理新发现的实例
        for instance in &discovered_instances {
            new_instance_ids.insert(instance.instance_id.clone());

            // 如果实例已存在，跳过
            if current_instances.contains_key(&instance.instance_id) {
                continue;
            }

            // 创建新的 Endpoint
            match Self::instance_to_endpoint(instance) {
                Ok(endpoint) => {
                    current_instances.insert(instance.instance_id.clone(), endpoint);

                    info!(
                        service_type = %service_type,
                        instance_id = %instance.instance_id,
                        address = %instance.address,
                        "Discovered new service instance"
                    );
                }
                Err(e) => {
                    warn!(
                        service_type = %service_type,
                        instance_id = %instance.instance_id,
                        error = %e,
                        "Failed to create endpoint for instance"
                    );
                }
            }
        }

        // 移除不再存在的实例
        let mut to_remove = Vec::new();
        for (instance_id, _) in current_instances.iter() {
            if !new_instance_ids.contains(instance_id) {
                to_remove.push(instance_id.clone());
            }
        }

        for instance_id in to_remove {
            current_instances.remove(&instance_id);
            info!(
                service_type = %service_type,
                instance_id = %instance_id,
                "Removed stale service instance"
            );
        }

        Ok(())
    }

    /// 将 Instance 转换为 Endpoint
    fn instance_to_endpoint(instance: &Instance) -> Result<Endpoint, Box<dyn std::error::Error>> {
        // 确保地址格式正确
        let address = if instance.address.starts_with("http://") || instance.address.starts_with("https://") {
            instance.address.clone()
        } else {
            format!("http://{}", instance.address)
        };

        let endpoint = Endpoint::from_shared(address.clone())
            .map_err(|e| format!("Failed to create endpoint from address {}: {}", address, e))?;

        Ok(endpoint)
    }
}

// 注意：Tower 0.5 的 Discover trait 实现比较复杂
// 当前我们提供简化版本，直接使用 Backend::discover 方法
// 完整的 Tower Discover 实现需要基于 Stream，将在后续版本中提供

// TODO: 实现完整的 Tower Discover trait
// 需要：
// 1. 将 Backend::discover 转换为 Stream
// 2. 实现 Change 事件的推送
// 3. 与 tower::balance::p2c 集成

/// 使用 Backend 创建负载均衡的 Channel（简化版本）
///
/// 这个版本直接使用 Backend 的 discover 方法，然后使用 Tonic 的 Channel::balance_list
///
/// # 参数
/// * `backend` - 后端实现
/// * `service_type` - 服务类型
///
/// # 返回
/// 返回一个负载均衡的 Channel
///
/// # 示例
/// ```rust,no_run
/// use flare_server_core::discovery::tower::create_balanced_channel_simple;
/// use flare_server_core::discovery::backend::Backend;
/// use std::sync::Arc;
/// use tokio::sync::RwLock;
///
/// # async fn example() -> Result<(), Box<dyn std::error::Error>> {
/// let backend: Arc<RwLock<Box<dyn Backend>>> = ...;
/// let channel = create_balanced_channel_simple(backend, "message-orchestrator".to_string()).await?;
/// # Ok(())
/// # }
/// ```
pub async fn create_balanced_channel_simple(
    backend: Arc<RwLock<Box<dyn Backend>>>,
    service_type: String,
) -> Result<Channel, Box<dyn std::error::Error>> {
    let backend_guard = backend.read().await;
    let instances = backend_guard.discover(&service_type).await?;
    drop(backend_guard);

    if instances.is_empty() {
        return Err(format!("No instances found for service type: {}", service_type).into());
    }

    // 将 Instance 转换为 Endpoint
    let endpoints: Result<Vec<Endpoint>, Box<dyn std::error::Error>> = instances
        .iter()
        .filter(|instance| instance.healthy) // 只使用健康的实例
        .map(|instance| {
            let address = if instance.address.starts_with("http://") || instance.address.starts_with("https://") {
                instance.address.clone()
            } else {
                format!("http://{}", instance.address)
            };

            Endpoint::from_shared(address)
                .map_err(|e| format!("Failed to create endpoint: {}", e).into())
        })
        .collect();

    let endpoints = endpoints?;

    if endpoints.is_empty() {
        return Err(format!("No healthy instances found for service type: {}", service_type).into());
    }

    // 使用 Tonic 的 Channel::balance_list 创建负载均衡的 Channel
    // 注意：Tonic 0.14 可能没有 balance_list，我们需要使用其他方法
    // 我们可以使用 Endpoint::from_static 然后手动实现负载均衡
    // 或者使用 tower::balance::p2c::Balance

    // 简化实现：使用第一个 endpoint（实际应该使用负载均衡）
    // 更好的方法是使用 tower::balance::p2c::Balance
    if let Some(endpoint) = endpoints.first() {
        let channel = endpoint.connect().await?;
        return Ok(channel);
    }

    Err("No endpoints available".into())
}
