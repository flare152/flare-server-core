//! 服务变化监听器
//!
//! 提供服务变化监听功能，当服务实例发生变化时发送通知

use crate::discovery::instance::InstanceChange;
use async_broadcast::Receiver;
use std::sync::Arc;

/// 服务变化事件
#[derive(Debug, Clone)]
pub enum WatchEvent {
    /// 服务实例变化
    Change(InstanceChange),
    /// 服务类型变化
    ServiceTypeChange {
        added: Vec<String>,
        removed: Vec<String>,
    },
}

/// 服务变化监听器
///
/// 用于监听服务实例的变化，当服务实例新增、更新或删除时会收到通知
pub struct Watcher {
    service_type: String,
    receiver: Receiver<WatchEvent>,
}

impl Watcher {
    pub fn new(service_type: String, receiver: Receiver<WatchEvent>) -> Self {
        Self {
            service_type,
            receiver,
        }
    }

    /// 获取服务类型
    pub fn service_type(&self) -> &str {
        &self.service_type
    }

    /// 接收下一个变化事件
    pub async fn next(&mut self) -> Result<WatchEvent, Box<dyn std::error::Error>> {
        self.receiver.recv().await
            .map_err(|e| format!("Failed to receive watch event: {}", e).into())
    }
}

