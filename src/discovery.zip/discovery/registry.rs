//! 服务注册发现客户端
//!
//! 统一的服务注册发现接口，支持注册、发现、健康检查、服务变化监听

use crate::config::RegistryConfig;
use crate::discovery::backend::{Backend, BackendBuilder};
use crate::discovery::instance::{diff_instances, Instance};
use crate::discovery::watcher::{WatchEvent, Watcher};
use async_broadcast::{broadcast, Receiver, Sender};
use std::collections::HashMap;
use std::sync::Arc;
use std::time::{Duration, Instant};
use tokio::sync::RwLock;

/// 负载均衡策略
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LoadBalanceStrategy {
    /// 轮询（Round Robin）
    RoundRobin,
    /// 随机（Random）
    Random,
    /// 一致性哈希（Consistent Hash）
    ConsistentHash,
    /// 最少连接（Least Connections）
    LeastConnections,
}

/// 服务注册发现客户端
///
/// 提供统一的服务注册发现接口，支持：
/// - 服务注册和注销
/// - 服务发现（支持负载均衡）
/// - 自动健康检查
/// - 服务变化监听
#[derive(Clone)]
pub struct Registry {
    /// 后端实现
    backend: Arc<RwLock<Box<dyn Backend>>>,
    /// 负载均衡策略
    load_balance_strategy: LoadBalanceStrategy,
    /// 本地缓存
    cache: Arc<RwLock<HashMap<String, CachedInstances>>>,
    /// 缓存 TTL
    cache_ttl: Duration,
    /// 健康检查间隔
    health_check_interval: Duration,
    /// 服务变化通知发送器
    watchers: Arc<RwLock<HashMap<String, Sender<WatchEvent>>>>,
}

/// 缓存的服务实例
#[derive(Debug, Clone)]
struct CachedInstances {
    instances: Vec<Arc<Instance>>,
    updated_at: Instant,
}

impl Registry {
    /// 创建服务注册发现客户端
    ///
    /// # 参数
    /// * `backend` - 后端实现
    /// * `load_balance_strategy` - 负载均衡策略
    pub fn new(backend: Box<dyn Backend>, load_balance_strategy: LoadBalanceStrategy) -> Self {
        Self {
            backend: Arc::new(RwLock::new(backend)),
            load_balance_strategy,
            cache: Arc::new(RwLock::new(HashMap::new())),
            cache_ttl: Duration::from_secs(30),
            health_check_interval: Duration::from_secs(10),
            watchers: Arc::new(RwLock::new(HashMap::new())),
        }
    }

    /// 设置缓存 TTL
    pub fn set_cache_ttl(&mut self, ttl: Duration) {
        self.cache_ttl = ttl;
    }

    /// 设置健康检查间隔
    pub fn set_health_check_interval(&mut self, interval: Duration) {
        self.health_check_interval = interval;
    }

    // ========== 注册功能 ==========

    /// 注册服务实例
    pub async fn register(&self, instance: Arc<Instance>) -> Result<(), Box<dyn std::error::Error>> {
        let mut backend = self.backend.write().await;
        backend.register(instance.clone()).await?;
        
        // 注册服务后，如果使用 TTL 健康检查，需要启动健康检查任务
        // 因为 service_id 是在 register 中设置的，所以需要在这里启动
        backend.start_health_check(self.health_check_interval)?;

        // 更新本地缓存
        let mut cache = self.cache.write().await;
        let entry = cache
            .entry(instance.service_type.clone())
            .or_insert_with(|| CachedInstances {
                instances: Vec::new(),
                updated_at: Instant::now(),
            });
        
        // 检查是否已存在
        if let Some(existing) = entry.instances.iter_mut().find(|i| i.instance_id == instance.instance_id) {
            *existing = instance.clone();
        } else {
            entry.instances.push(instance.clone());
        }
        entry.updated_at = Instant::now();

        // 发送变化通知
        self.notify_change(&instance.service_type).await;

        Ok(())
    }

    /// 注销服务实例
    pub async fn unregister(&self, instance_id: &str) -> Result<(), Box<dyn std::error::Error>> {
        let mut backend = self.backend.write().await;
        backend.unregister(instance_id).await?;

        // 从缓存中移除
        let mut cache = self.cache.write().await;
        let mut service_type: Option<String> = None;
        for (st, cached) in cache.iter_mut() {
            if let Some(pos) = cached.instances.iter().position(|i| i.instance_id == instance_id) {
                cached.instances.remove(pos);
                cached.updated_at = Instant::now();
                service_type = Some(st.clone());
                break;
            }
        }

        // 发送变化通知
        if let Some(st) = service_type {
            self.notify_change(&st).await;
        }

        Ok(())
    }

    // ========== 发现功能 ==========

    /// 发现服务实例（获取指定类型的所有实例）
    ///
    /// # 参数
    /// * `service_type` - 服务类型
    /// * `include_unhealthy` - 是否包含不健康的实例（默认：false）
    /// * `version` - 可选的服务版本（用于版本过滤）
    ///
    /// # 返回
    /// 返回所有服务实例列表
    pub async fn discover(
        &self,
        service_type: &str,
        include_unhealthy: bool,
        version: Option<&str>,
    ) -> Result<Vec<Arc<Instance>>, Box<dyn std::error::Error>> {
        // 检查缓存
        {
            let cache = self.cache.read().await;
            if let Some(cached) = cache.get(service_type) {
                if cached.updated_at.elapsed() < self.cache_ttl {
                    let mut instances = if include_unhealthy {
                        cached.instances.clone()
                    } else {
                        cached.instances.iter()
                            .filter(|i| i.healthy)
                            .cloned()
                            .collect()
                    };
                    
                    // 版本过滤
                    if let Some(version) = version {
                        instances.retain(|instance| {
                            instance.version.as_ref().map(|v| v == version).unwrap_or(false)
                        });
                    }
                    
                    return Ok(instances);
                }
            }
        }

        // 从后端获取
        let backend = self.backend.read().await;
        let mut instances = backend.discover(service_type).await?;

        // 版本过滤
        if let Some(version) = version {
            instances.retain(|instance| {
                instance.version.as_ref().map(|v| v == version).unwrap_or(false)
            });
        }

        // 更新缓存（缓存所有版本，过滤在查询时进行）
        {
            let mut cache = self.cache.write().await;
            // 重新获取所有实例用于缓存（不进行版本过滤）
            let backend = self.backend.read().await;
            let all_instances = backend.discover(service_type).await?;
            cache.insert(
                service_type.to_string(),
                CachedInstances {
                    instances: all_instances,
                    updated_at: Instant::now(),
                },
            );
        }

        // 过滤不健康的实例
        let instances = if include_unhealthy {
            instances
        } else {
            instances.into_iter()
                .filter(|i| i.healthy)
                .collect()
        };

        Ok(instances)
    }

    /// 获取服务实例（带负载均衡）
    ///
    /// # 参数
    /// * `service_type` - 服务类型
    /// * `key` - 可选的一致性哈希键（用于一致性哈希负载均衡）
    ///             如果 key 格式为 "gateway_id=xxx"，则按 gateway_id 标签精确匹配
    /// * `include_unhealthy` - 是否包含不健康的实例（默认：false）
    /// * `version` - 可选的服务版本（用于版本过滤）
    ///
    /// # 返回
    /// 返回一个服务实例（根据负载均衡策略选择）
    pub async fn select_instance(
        &self,
        service_type: &str,
        key: Option<&str>,
        include_unhealthy: bool,
        version: Option<&str>,
    ) -> Result<Option<Arc<Instance>>, Box<dyn std::error::Error>> {
        let instances = self.discover(service_type, include_unhealthy, version).await?;
        
        if instances.is_empty() {
            return Ok(None);
        }

        // 如果 key 格式为 "gateway_id=xxx"，则按 gateway_id 标签精确匹配
        let filtered_instances = if let Some(key_str) = key {
            if key_str.starts_with("gateway_id=") {
                let target_gateway_id = key_str.strip_prefix("gateway_id=").unwrap_or(key_str);
                instances.into_iter()
                    .filter(|instance| {
                        instance.tags.get("gateway_id")
                            .map(|v| v.as_ref() == target_gateway_id)
                            .unwrap_or(false)
                    })
                    .collect::<Vec<_>>()
            } else {
                instances
            }
        } else {
            instances
        };

        if filtered_instances.is_empty() {
            return Ok(None);
        }

        // 使用负载均衡策略选择实例
        let selected = match self.load_balance_strategy {
            LoadBalanceStrategy::RoundRobin => {
                // 简单的轮询（基于实例数量）
                let index = if let Some(key) = key {
                    // 使用 key 的哈希值进行选择
                    use std::hash::{Hash, Hasher};
                    let mut hasher = std::collections::hash_map::DefaultHasher::new();
                    key.hash(&mut hasher);
                    (hasher.finish() as usize) % filtered_instances.len()
                } else {
                    0
                };
                filtered_instances.get(index).cloned()
            }
            LoadBalanceStrategy::Random => {
                use rand::Rng;
                let mut rng = rand::thread_rng();
                filtered_instances.get(rng.gen_range(0..filtered_instances.len())).cloned()
            }
            LoadBalanceStrategy::ConsistentHash => {
                if let Some(key) = key {
                    // 一致性哈希
                    use std::hash::{Hash, Hasher};
                    let mut hasher = std::collections::hash_map::DefaultHasher::new();
                    key.hash(&mut hasher);
                    let hash = hasher.finish();
                    filtered_instances.get((hash as usize) % filtered_instances.len()).cloned()
                } else {
                    filtered_instances.first().cloned()
                }
            }
            LoadBalanceStrategy::LeastConnections => {
                // 最少连接（简化实现，选择权重最高的）
                filtered_instances.iter()
                    .max_by_key(|i| i.weight)
                    .cloned()
            }
        };

        Ok(selected)
    }

    /// 获取服务地址（带负载均衡）
    ///
    /// # 参数
    /// * `service_type` - 服务类型
    /// * `key` - 可选的一致性哈希键
    /// * `include_unhealthy` - 是否包含不健康的实例（默认：false）
    /// * `version` - 可选的服务版本（用于版本过滤）
    ///
    /// # 返回
    /// 返回服务地址，格式：`http://address:port`
    pub async fn get_service_address(
        &self,
        service_type: &str,
        key: Option<&str>,
        include_unhealthy: bool,
        version: Option<&str>,
    ) -> Result<Option<String>, Box<dyn std::error::Error>> {
        if let Some(instance) = self.select_instance(service_type, key, include_unhealthy, version).await? {
            Ok(Some(instance.http_address()))
        } else {
            Ok(None)
        }
    }

    /// 获取所有服务类型
    pub async fn list_service_types(&self) -> Result<Vec<String>, Box<dyn std::error::Error>> {
        let backend = self.backend.read().await;
        backend.list_service_types().await
    }

    /// 获取所有服务实例
    pub async fn list_all_instances(
        &self,
        include_unhealthy: bool,
    ) -> Result<Vec<Arc<Instance>>, Box<dyn std::error::Error>> {
        let backend = self.backend.read().await;
        let instances = backend.list_all_instances().await?;
        
        if include_unhealthy {
            Ok(instances)
        } else {
            Ok(instances.into_iter().filter(|i| i.healthy).collect())
        }
    }

    // ========== 健康检查 ==========

    /// 启动自动健康检查
    pub async fn start_health_check(&self) -> Result<(), Box<dyn std::error::Error>> {
        let mut backend = self.backend.write().await;
        backend.start_health_check(self.health_check_interval)?;
        Ok(())
    }

    /// 停止自动健康检查
    pub async fn stop_health_check(&self) -> Result<(), Box<dyn std::error::Error>> {
        let mut backend = self.backend.write().await;
        backend.stop_health_check()?;
        Ok(())
    }

    /// 刷新缓存
    pub async fn refresh_cache(&self, service_type: Option<&str>) -> Result<(), Box<dyn std::error::Error>> {
        if let Some(service_type) = service_type {
            // 刷新指定服务类型的缓存
            let backend = self.backend.read().await;
            let instances = backend.discover(service_type).await?;

            let mut cache = self.cache.write().await;
            cache.insert(
                service_type.to_string(),
                CachedInstances {
                    instances,
                    updated_at: Instant::now(),
                },
            );
        } else {
            // 刷新所有缓存
            let backend = self.backend.read().await;
            let service_types = backend.list_service_types().await?;

            let mut cache = self.cache.write().await;
            for service_type in service_types {
                if let Ok(instances) = backend.discover(&service_type).await {
                    cache.insert(
                        service_type,
                        CachedInstances {
                            instances,
                            updated_at: Instant::now(),
                        },
                    );
                }
            }
        }

        Ok(())
    }

    // ========== 服务变化监听 ==========

    /// 监听服务变化
    ///
    /// # 参数
    /// * `service_type` - 服务类型
    ///
    /// # 返回
    /// 返回 Watcher，可以用于接收服务变化通知
    pub async fn watch(&self, service_type: &str) -> Result<Watcher, Box<dyn std::error::Error>> {
        let mut watchers = self.watchers.write().await;
        
        // 获取或创建发送器
        let sender = watchers.entry(service_type.to_string()).or_insert_with(|| {
            let (tx, _rx) = broadcast(100);
            tx
        });

        // 创建新的接收器（每个 watcher 需要独立的接收器）
        let receiver = sender.new_receiver();

        Ok(Watcher::new(service_type.to_string(), receiver))
    }

    /// 通知服务变化（内部方法）
    async fn notify_change(&self, service_type: &str) {
               // 获取当前实例列表（不进行版本过滤，获取所有版本）
               let current_instances = match self.discover(service_type, true, None).await {
            Ok(instances) => instances,
            Err(_) => return,
        };

        // 获取之前的实例列表（从缓存）
        let prev_instances = {
            let cache = self.cache.read().await;
            cache.get(service_type)
                .map(|cached| cached.instances.clone())
                .unwrap_or_default()
        };

        // 计算变化
        let change = diff_instances(service_type.to_string(), prev_instances, current_instances);

        // 发送通知
        if change.has_changes() {
            let watchers = self.watchers.read().await;
            if let Some(sender) = watchers.get(service_type) {
                let _ = sender.broadcast(WatchEvent::Change(change)).await;
            }
        }
    }

    /// 健康检查
    pub async fn health_check(&self) -> Result<(), Box<dyn std::error::Error>> {
        let backend = self.backend.read().await;
        backend.health_check().await
    }
}

/// 服务注册发现构建器
pub struct RegistryBuilder {
    config: Option<RegistryConfig>,
    load_balance_strategy: Option<LoadBalanceStrategy>,
    cache_ttl: Option<Duration>,
    health_check_interval: Option<Duration>,
}

impl RegistryBuilder {
    pub fn new() -> Self {
        Self {
            config: None,
            load_balance_strategy: None,
            cache_ttl: None,
            health_check_interval: None,
        }
    }

    pub fn with_config(mut self, config: RegistryConfig) -> Self {
        self.config = Some(config);
        self
    }

    pub fn with_load_balance_strategy(mut self, strategy: LoadBalanceStrategy) -> Self {
        self.load_balance_strategy = Some(strategy);
        self
    }

    pub fn with_cache_ttl(mut self, ttl: Duration) -> Self {
        self.cache_ttl = Some(ttl);
        self
    }

    pub fn with_health_check_interval(mut self, interval: Duration) -> Self {
        self.health_check_interval = Some(interval);
        self
    }

    pub async fn build(self) -> Result<Registry, Box<dyn std::error::Error>> {
        let config = self.config.ok_or("Registry config is required")?;
        let strategy = self.load_balance_strategy
            .unwrap_or(LoadBalanceStrategy::ConsistentHash);

        let backend = BackendBuilder::new()
            .with_config(config)
            .build()
            .await?;

        let mut registry = Registry::new(backend, strategy);

        if let Some(ttl) = self.cache_ttl {
            registry.set_cache_ttl(ttl);
        }

        if let Some(interval) = self.health_check_interval {
            registry.set_health_check_interval(interval);
        }

        // 注意：健康检查会在注册服务时自动启动（在 register 方法中）
        // 这里不需要手动启动，避免在没有 service_id 时启动失败

        Ok(registry)
    }
}

impl Default for RegistryBuilder {
    fn default() -> Self {
        Self::new()
    }
}

