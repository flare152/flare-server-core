//! Consul 后端实现

use crate::discovery::backend::Backend;
use crate::discovery::instance::Instance;
use async_trait::async_trait;
use serde::{Deserialize, Serialize};
use std::borrow::Cow;
use std::collections::HashMap;
use std::sync::Arc;
use std::time::Duration;
use tracing::info;

/// Consul 后端实现
pub struct ConsulBackend {
    client: reqwest::Client,
    base_url: String,
    namespace: String,
    ttl: u64,
    service_id: Option<String>,
    health_check_handle: Option<tokio::task::JoinHandle<()>>,
}

#[allow(non_snake_case)]
#[derive(Serialize, Deserialize)]
struct ConsulService {
    ID: String,
    Name: String,
    Tags: Vec<String>,
    Address: String,
    Port: u16,
    Check: ConsulCheck,
}

#[allow(non_snake_case)]
#[derive(Debug, Serialize, Deserialize)]
struct ConsulCheck {
    #[serde(skip_serializing_if = "Option::is_none")]
    HTTP: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    TCP: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    TTL: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    Interval: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    Timeout: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    DeregisterCriticalServiceAfter: Option<String>,
}

#[derive(Deserialize)]
struct ConsulHealthResponse {
    #[serde(rename = "Node")]
    Node: ConsulNode,
    #[serde(rename = "Service")]
    Service: ConsulServiceResponse,
    #[serde(rename = "Checks")]
    Checks: Vec<ConsulCheckResponse>,
}

#[derive(Deserialize)]
struct ConsulNode {
    #[serde(rename = "ID")]
    ID: String,
    #[serde(rename = "Node")]
    Node: String,
    #[serde(rename = "Address")]
    Address: String,
}

#[derive(Deserialize)]
struct ConsulCheckResponse {
    #[serde(rename = "Status")]
    Status: String,
    #[serde(rename = "ServiceID")]
    ServiceID: String,
}

#[derive(Deserialize)]
struct ConsulServiceResponse {
    #[serde(rename = "ID")]
    ID: String,
    #[serde(rename = "Service")]
    Service: String,
    #[serde(rename = "Address")]
    Address: String,
    #[serde(rename = "Port")]
    Port: u16,
    #[serde(rename = "Tags")]
    Tags: Vec<String>,
}

impl ConsulBackend {
    pub async fn new(
        consul_endpoints: Vec<String>,
        namespace: String,
        ttl: u64,
    ) -> Result<Self, Box<dyn std::error::Error>> {
        let base_url = consul_endpoints
            .first()
            .ok_or("No Consul endpoint provided")?
            .clone();

        // 创建带超时的 HTTP 客户端（5秒超时，防止阻塞）
        let client = reqwest::Client::builder()
            .timeout(Duration::from_secs(5))
            .build()
            .map_err(|e| format!("Failed to create HTTP client: {}", e))?;

        Ok(Self {
            client,
            base_url,
            namespace,
            ttl,
            service_id: None,
            health_check_handle: None,
        })
    }
}

#[async_trait]
impl Backend for ConsulBackend {
    async fn register(&mut self, instance: Arc<Instance>) -> Result<(), Box<dyn std::error::Error>> {
        let service_id = format!("{}-{}", instance.service_type, instance.instance_id);
        self.service_id = Some(service_id.clone());

        // 构建标签列表，包含版本信息和权重
        let mut tags = Vec::new();
        if let Some(version) = &instance.version {
            tags.push(format!("version={}", version));
        }
        // 保存权重到标签（Consul 不支持权重字段，需要通过标签传递）
        if instance.weight != 1 {
            tags.push(format!("weight={}", instance.weight));
        }
        // 添加其他标签
        for (key, value) in &instance.tags {
            tags.push(format!("{}={}", key, value));
        }

        // 解析地址和端口
        let mut address = instance.address.split(':').next().unwrap_or(&instance.address).to_string();
        let port = instance.address.split(':').last()
            .and_then(|p| p.parse::<u16>().ok())
            .unwrap_or(80);
        
        // Consul 不能使用 0.0.0.0，需要转换为实际地址
        // 如果是 0.0.0.0，使用 127.0.0.1（本地开发）或实际的本机 IP
        if address == "0.0.0.0" {
            address = "127.0.0.1".to_string();
        }
        
        // 健康检查策略：
        // 1. 如果服务有 HTTP 健康检查端点，使用 HTTP 检查
        // 2. 否则使用 TTL 检查（服务自己上报健康状态，避免启动时检查失败）
        let use_http_check = instance.tags.get("health_check_type")
            .map(|v| v.as_ref() == "http")
            .unwrap_or(false);
        
        let check = if use_http_check {
            ConsulCheck {
                HTTP: Some(format!("http://{}:{}/health", address, port)),
                TCP: None,
                TTL: None,
                Interval: Some(format!("{}s", self.ttl / 3)),
                Timeout: Some("5s".to_string()),
                DeregisterCriticalServiceAfter: Some(format!("{}s", self.ttl * 2)),
            }
        } else {
            // 使用 TTL 健康检查：服务自己定期上报健康状态
            // 这样避免服务启动时 TCP 连接失败导致立即下线
            ConsulCheck {
                HTTP: None,
                TCP: None,
                TTL: Some(format!("{}s", self.ttl)),
                Interval: None,
                Timeout: None,
                DeregisterCriticalServiceAfter: Some(format!("{}s", self.ttl * 2)),
            }
        };
        
        let consul_service = ConsulService {
            ID: service_id.clone(),
            Name: format!("{}/{}", self.namespace, instance.service_type),
            Tags: tags,
            Address: address.clone(),
            Port: port,
            Check: check,
        };

        let url = format!("{}/v1/agent/service/register", self.base_url);
        
        // 记录注册信息用于调试
        tracing::debug!(
            "Registering service with Consul: ID={}, Name={}, Address={}, Port={}, Check={:?}",
            consul_service.ID,
            consul_service.Name,
            consul_service.Address,
            consul_service.Port,
            consul_service.Check
        );
        
        let response = self.client
            .put(&url)
            .json(&consul_service)
            .send()
            .await
            .map_err(|e| format!("Failed to register service with Consul: {}", e))?;
        
        if !response.status().is_success() {
            let status = response.status();
            let error_text = response.text().await.unwrap_or_else(|_| "Unknown error".to_string());
            tracing::error!(
                "Consul registration failed: HTTP {} - {}",
                status, error_text
            );
            return Err(format!(
                "Failed to register service with Consul: HTTP {} - {}",
                status, error_text
            ).into());
        }

        info!(
            "Service registered with Consul: {} at {}:{}",
            instance.service_type, address, port
        );
        
        // 如果使用 TTL 健康检查，立即上报一次健康状态
        // 避免服务注册后立即被标记为不健康
        if consul_service.Check.TTL.is_some() {
            let check_id = format!("service:{}", service_id);
            let pass_url = format!("{}/v1/agent/check/pass/{}", self.base_url, check_id);
            // 重试几次，确保健康检查上报成功
            let mut retries = 3;
            while retries > 0 {
                match self.client.put(&pass_url).send().await {
                    Ok(_) => {
                        tracing::debug!(check_id = %check_id, "Initial TTL health check reported");
                        break;
                    }
                    Err(e) => {
                        retries -= 1;
                        if retries > 0 {
                tracing::warn!(
                    check_id = %check_id,
                    error = %e,
                                retries_left = retries,
                                "Failed to report initial TTL health check, retrying"
                );
                            tokio::time::sleep(Duration::from_millis(100)).await;
            } else {
                            tracing::warn!(
                                check_id = %check_id,
                                error = %e,
                                "Failed to report initial TTL health check after retries"
                            );
                        }
                    }
                }
            }
        }

        Ok(())
    }

    async fn unregister(&mut self, instance_id: &str) -> Result<(), Box<dyn std::error::Error>> {
        // 注意：注册时 service_id 格式是 "{service_type}-{instance_id}"
        // 如果传入的 instance_id 已经是完整的 service_id（包含 service_type 前缀），直接使用
        // 否则，尝试使用保存的 service_id，或者从 Consul 查询找到匹配的 service_id
        let service_id = if let Some(saved_service_id) = &self.service_id {
            // 如果保存的 service_id 以传入的 instance_id 结尾，使用保存的
            if saved_service_id.ends_with(instance_id) {
                saved_service_id.clone()
            } else {
                // 否则，假设传入的就是完整的 service_id
                instance_id.to_string()
            }
        } else {
            // 没有保存的 service_id，假设传入的就是完整的 service_id
            instance_id.to_string()
        };

        let url = format!("{}/v1/agent/service/deregister/{}", self.base_url, service_id);
        let response = self.client
            .put(&url)
            .send()
            .await
            .map_err(|e| format!("Failed to unregister service from Consul: {}", e))?;
        
        if !response.status().is_success() {
            return Err(format!("Failed to unregister service from Consul: HTTP {}", response.status()).into());
        }

        info!("Service unregistered from Consul: {}", instance_id);
        Ok(())
    }

    async fn discover(&self, service_type: &str) -> Result<Vec<Arc<Instance>>, Box<dyn std::error::Error>> {
        let service_name = format!("{}/{}", self.namespace, service_type);
        // 注意：使用 ?passing=true 只返回健康的服务
        // 但对于 TTL 健康检查，可能需要一些时间才能变为 passing 状态
        // 如果服务刚注册，可能需要等待健康检查上报
        let url = format!("{}/v1/health/service/{}?passing=true", self.base_url, service_name);

        let response = self.client
            .get(&url)
            .send()
            .await
            .map_err(|e| format!("Failed to discover services from Consul: {}", e))?;

        if !response.status().is_success() {
            // 如果服务不存在，返回空列表而不是错误
            if response.status() == 404 {
                return Ok(Vec::new());
            }
            return Err(format!("Failed to discover services from Consul: HTTP {}", response.status()).into());
        }

        // 检查响应体是否为空
        let response_text = response.text().await
            .map_err(|e| format!("Failed to read Consul response: {}", e))?;
        
        // 如果响应为空，返回空列表
        if response_text.trim().is_empty() || response_text.trim() == "[]" {
            return Ok(Vec::new());
        }
        
        let health_responses: Vec<ConsulHealthResponse> = serde_json::from_str(&response_text)
            .map_err(|e| format!("Failed to parse Consul response: {} (response: {})", e, response_text))?;

        let mut instances = Vec::new();
        for health in health_responses {
            let service = health.Service;
            
            // 从 service.ID 中提取原始的 instance_id
            // service.ID 格式是 "{service_type}-{instance_id}"
            // 需要提取出原始的 instance_id
            let instance_id = if service.ID.starts_with(&format!("{}-", service_type)) {
                service.ID.strip_prefix(&format!("{}-", service_type))
                    .unwrap_or(&service.ID)
                    .to_string()
            } else {
                // 如果格式不匹配，使用完整的 service.ID
                service.ID.clone()
            };
            
            // 从标签中提取版本信息和权重（先克隆标签，避免生命周期问题）
            let tags = service.Tags.clone();
            let version = tags.iter()
                .find_map(|tag| {
                    if tag.starts_with("version=") {
                        Some(tag.strip_prefix("version=").unwrap_or("").to_string())
                    } else {
                        None
                    }
                });
            
            // 从标签中提取权重（默认权重为 1）
            let weight = tags.iter()
                .find_map(|tag| {
                    if tag.starts_with("weight=") {
                        tag.strip_prefix("weight=")
                            .and_then(|w| w.parse::<u32>().ok())
                    } else {
                        None
                    }
                })
                .unwrap_or(1);

            // 从 Checks 中获取健康状态（查找 passing 状态的检查）
            let is_healthy = health.Checks.iter()
                .any(|check| check.Status == "passing" && check.ServiceID == service.ID);
            
            let mut instance = if let Some(version) = version {
                Instance::new_with_version(
                    format!("{}:{}", service.Address, service.Port),
                    service_type.to_string(),
                    instance_id,
                    version,
                )
            } else {
                Instance::new(
                    format!("{}:{}", service.Address, service.Port),
                    service_type.to_string(),
                    instance_id,
                )
            };
            
            // 设置权重和健康状态
            instance.weight = weight;
            instance.healthy = is_healthy;

            // 添加其他标签（排除 version 和 weight，因为已经作为字段存储）
            // 先收集所有标签，然后一次性设置，避免生命周期问题
            let mut instance_tags = std::collections::HashMap::new();
            for tag in &tags {
                if !tag.starts_with("version=") && !tag.starts_with("weight=") {
                    if let Some((key, value)) = tag.split_once('=') {
                        instance_tags.insert(Cow::Owned(key.to_string()), Cow::Owned(value.to_string()));
                    }
                }
            }
            instance_tags.insert(Cow::Borrowed("consul.service"), Cow::Owned(service.Service.clone()));
            instance_tags.insert(Cow::Borrowed("consul.node"), Cow::Owned(health.Node.Node.clone()));
            instance_tags.insert(Cow::Borrowed("consul.node_id"), Cow::Owned(health.Node.ID.clone()));
            
            // 从 Checks 中获取状态信息
            if let Some(check) = health.Checks.iter().find(|c| c.ServiceID == service.ID) {
                instance_tags.insert(Cow::Borrowed("consul.status"), Cow::Owned(check.Status.clone()));
            }
            
            instance = instance.with_tags(instance_tags);

            instances.push(Arc::new(instance));
        }

        Ok(instances)
    }

    async fn list_service_types(&self) -> Result<Vec<String>, Box<dyn std::error::Error>> {
        let url = format!("{}/v1/catalog/services", self.base_url);
        let response = self.client
            .get(&url)
            .send()
            .await
            .map_err(|e| format!("Failed to list services from Consul: {}", e))?;

        if !response.status().is_success() {
            return Err(format!("Failed to list services from Consul: HTTP {}", response.status()).into());
        }

        // 检查响应体是否为空
        let response_text = response.text().await
            .map_err(|e| format!("Failed to read Consul response: {}", e))?;
        
        // 如果响应为空，返回空列表
        if response_text.trim().is_empty() || response_text.trim() == "{}" {
            return Ok(Vec::new());
        }
        
        let services: HashMap<String, Vec<String>> = serde_json::from_str(&response_text)
            .map_err(|e| format!("Failed to parse Consul response: {} (response: {})", e, response_text))?;

        let mut service_types = Vec::new();
        let namespace_prefix = format!("{}/", self.namespace);
        for (service_name, _tags) in services {
            if service_name.starts_with(&namespace_prefix) {
                let service_type = service_name.strip_prefix(&namespace_prefix)
                    .unwrap_or(&service_name)
                    .to_string();
                service_types.push(service_type);
            }
        }

        Ok(service_types)
    }

    async fn list_all_instances(&self) -> Result<Vec<Arc<Instance>>, Box<dyn std::error::Error>> {
        let service_types = self.list_service_types().await?;
        let mut all_instances = Vec::new();

        for service_type in service_types {
            if let Ok(instances) = self.discover(&service_type).await {
                all_instances.extend(instances);
            }
        }

        Ok(all_instances)
    }

    async fn health_check(&self) -> Result<(), Box<dyn std::error::Error>> {
        let url = format!("{}/v1/status/leader", self.base_url);
        let response = self.client
            .get(&url)
            .send()
            .await
            .map_err(|e| format!("Consul health check failed: {}", e))?;
        
        if !response.status().is_success() {
            return Err(format!("Consul health check failed: HTTP {}", response.status()).into());
        }
        
        Ok(())
    }

    fn start_health_check(&mut self, interval: Duration) -> Result<(), Box<dyn std::error::Error>> {
        // 如果已经启动了健康检查任务，不要重复启动
        if self.health_check_handle.is_some() {
            return Ok(());
        }
        
        // 如果使用 TTL 健康检查，需要定期上报健康状态
        // TTL 健康检查的上报间隔应该是 TTL 的一半，确保在 TTL 过期前更新
        if let Some(service_id) = &self.service_id {
            let service_id = service_id.clone();
            let base_url = self.base_url.clone();
            let client = self.client.clone();
            let check_id = format!("service:{}", service_id);
            
            // TTL 上报间隔：使用 TTL 的一半，确保在过期前更新
            // 但不超过传入的 interval（通常是健康检查间隔）
            let ttl_seconds = self.ttl;
            let report_interval = Duration::from_secs(ttl_seconds / 2).min(interval);
            
            tracing::info!(
                check_id = %check_id,
                report_interval_secs = report_interval.as_secs(),
                ttl_secs = ttl_seconds,
                "Starting TTL health check reporter"
            );
            
            // 启动 TTL 健康检查上报任务
            let handle = tokio::spawn(async move {
                let mut interval_timer = tokio::time::interval(report_interval);
                interval_timer.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
                
                // 立即上报一次，避免等待第一个间隔
                let url = format!("{}/v1/agent/check/pass/{}", base_url, check_id);
                if let Err(e) = client.put(&url).send().await {
                    tracing::warn!(
                        check_id = %check_id,
                        error = %e,
                        "Failed to report initial TTL health check"
                    );
                } else {
                    tracing::info!(check_id = %check_id, "Initial TTL health check reported");
                }
                
                loop {
                    interval_timer.tick().await;
                    
                    // 上报健康状态：pass
                    let url = format!("{}/v1/agent/check/pass/{}", base_url, check_id);
                    if let Err(e) = client.put(&url).send().await {
                        tracing::warn!(
                            check_id = %check_id,
                            error = %e,
                            "Failed to update TTL health check"
                        );
                    } else {
                        tracing::debug!(check_id = %check_id, "TTL health check updated");
                    }
                }
            });
            
            self.health_check_handle = Some(handle);
        } else {
            tracing::debug!("Service ID not set, skipping TTL health check startup");
        }
        
        Ok(())
    }

    fn stop_health_check(&mut self) -> Result<(), Box<dyn std::error::Error>> {
        if let Some(handle) = self.health_check_handle.take() {
            handle.abort();
        }
        Ok(())
    }
}

impl ConsulBackend {
    #[allow(dead_code)] // 保留用于未来扩展
    async fn list_service_types_internal(
        client: &reqwest::Client,
        base_url: &str,
        namespace: &str,
    ) -> Result<Vec<String>, Box<dyn std::error::Error>> {
        let url = format!("{}/v1/catalog/services", base_url);
        let response = client
            .get(&url)
            .send()
            .await
            .map_err(|e| format!("Failed to list services from Consul: {}", e))?;

        if !response.status().is_success() {
            return Err(format!("Failed to list services from Consul: HTTP {}", response.status()).into());
        }

        let services: HashMap<String, Vec<String>> = response
            .json()
            .await
            .map_err(|e| format!("Failed to parse Consul response: {}", e))?;

        let mut service_types = Vec::new();
        let namespace_prefix = format!("{}/", namespace);
        for (service_name, _tags) in services {
            if service_name.starts_with(&namespace_prefix) {
                let service_type = service_name.strip_prefix(&namespace_prefix)
                    .unwrap_or(&service_name)
                    .to_string();
                service_types.push(service_type);
            }
        }

        Ok(service_types)
    }

    #[allow(dead_code)] // 保留用于未来扩展
    async fn discover_internal(
        client: &reqwest::Client,
        base_url: &str,
        namespace: &str,
        service_type: &str,
    ) -> Result<Vec<Arc<Instance>>, Box<dyn std::error::Error>> {
        let service_name = format!("{}/{}", namespace, service_type);
        let url = format!("{}/v1/health/service/{}?passing=true", base_url, service_name);

        let response = client
            .get(&url)
            .send()
            .await
            .map_err(|e| format!("Failed to discover services from Consul: {}", e))?;

        if !response.status().is_success() {
            if response.status() == 404 {
                return Ok(Vec::new());
            }
            return Err(format!("Failed to discover services from Consul: HTTP {}", response.status()).into());
        }

        // 检查响应体是否为空
        let response_text = response.text().await
            .map_err(|e| format!("Failed to read Consul response: {}", e))?;
        
        // 如果响应为空，返回空列表
        if response_text.trim().is_empty() || response_text.trim() == "[]" {
            return Ok(Vec::new());
        }
        
        let health_responses: Vec<ConsulHealthResponse> = serde_json::from_str(&response_text)
            .map_err(|e| format!("Failed to parse Consul response: {} (response: {})", e, response_text))?;

        let mut instances = Vec::new();
        for health in health_responses {
            let service = health.Service;
            
            // 从 service.ID 中提取原始的 instance_id
            // service.ID 格式是 "{service_type}-{instance_id}"
            // 需要提取出原始的 instance_id
            let instance_id = if service.ID.starts_with(&format!("{}-", service_type)) {
                service.ID.strip_prefix(&format!("{}-", service_type))
                    .unwrap_or(&service.ID)
                    .to_string()
            } else {
                // 如果格式不匹配，使用完整的 service.ID
                service.ID.clone()
            };
            
            // 从标签中提取版本信息和权重（先克隆标签，避免生命周期问题）
            let tags = service.Tags.clone();
            let version = tags.iter()
                .find_map(|tag| {
                    if tag.starts_with("version=") {
                        Some(tag.strip_prefix("version=").unwrap_or("").to_string())
                    } else {
                        None
                    }
                });
            
            // 从标签中提取权重（默认权重为 1）
            let weight = tags.iter()
                .find_map(|tag| {
                    if tag.starts_with("weight=") {
                        tag.strip_prefix("weight=")
                            .and_then(|w| w.parse::<u32>().ok())
                    } else {
                        None
                    }
                })
                .unwrap_or(1);

            // 从 Checks 中获取健康状态（查找 passing 状态的检查）
            let is_healthy = health.Checks.iter()
                .any(|check| check.Status == "passing" && check.ServiceID == service.ID);
            
            let mut instance = if let Some(version) = version {
                Instance::new_with_version(
                    format!("{}:{}", service.Address, service.Port),
                    service_type.to_string(),
                    instance_id,
                    version,
                )
            } else {
                Instance::new(
                    format!("{}:{}", service.Address, service.Port),
                    service_type.to_string(),
                    instance_id,
                )
            };
            
            // 设置权重和健康状态
            instance.weight = weight;
            instance.healthy = is_healthy;

            // 添加其他标签（排除 version 和 weight，因为已经作为字段存储）
            // 先收集所有标签，然后一次性设置，避免生命周期问题
            let mut instance_tags = std::collections::HashMap::new();
            for tag in &tags {
                if !tag.starts_with("version=") && !tag.starts_with("weight=") {
                    if let Some((key, value)) = tag.split_once('=') {
                        instance_tags.insert(Cow::Owned(key.to_string()), Cow::Owned(value.to_string()));
                    }
                }
            }
            instance_tags.insert(Cow::Borrowed("consul.service"), Cow::Owned(service.Service.clone()));
            instance_tags.insert(Cow::Borrowed("consul.node"), Cow::Owned(health.Node.Node.clone()));
            instance_tags.insert(Cow::Borrowed("consul.node_id"), Cow::Owned(health.Node.ID.clone()));
            
            // 从 Checks 中获取状态信息
            if let Some(check) = health.Checks.iter().find(|c| c.ServiceID == service.ID) {
                instance_tags.insert(Cow::Borrowed("consul.status"), Cow::Owned(check.Status.clone()));
            }
            
            instance = instance.with_tags(instance_tags);

            instances.push(Arc::new(instance));
        }

        Ok(instances)
    }
}

