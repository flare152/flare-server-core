//! 服务注册发现后端实现模块
//!
//! 支持多种后端：etcd、Consul、Service Mesh

pub mod consul;
pub mod etcd;
pub mod mesh;

use crate::config::RegistryConfig;
use crate::discovery::instance::Instance;
use async_trait::async_trait;
use std::sync::Arc;

pub use consul::ConsulBackend;
pub use etcd::EtcdBackend;
pub use mesh::MeshBackend;

/// 服务注册发现后端 Trait
///
/// 定义统一的后端接口，所有后端实现都需要实现此 trait
#[async_trait]
pub trait Backend: Send + Sync + 'static {
    /// 注册服务实例
    async fn register(&mut self, instance: Arc<Instance>) -> Result<(), Box<dyn std::error::Error>>;

    /// 注销服务实例
    async fn unregister(&mut self, instance_id: &str) -> Result<(), Box<dyn std::error::Error>>;

    /// 发现服务实例（获取指定类型的所有实例）
    async fn discover(&self, service_type: &str) -> Result<Vec<Arc<Instance>>, Box<dyn std::error::Error>>;

    /// 获取所有服务类型
    async fn list_service_types(&self) -> Result<Vec<String>, Box<dyn std::error::Error>>;

    /// 获取所有服务实例
    async fn list_all_instances(&self) -> Result<Vec<Arc<Instance>>, Box<dyn std::error::Error>>;

    /// 健康检查
    async fn health_check(&self) -> Result<(), Box<dyn std::error::Error>>;

    /// 启动健康检查（自动检查服务实例的健康状态）
    fn start_health_check(&mut self, interval: std::time::Duration) -> Result<(), Box<dyn std::error::Error>>;

    /// 停止健康检查
    fn stop_health_check(&mut self) -> Result<(), Box<dyn std::error::Error>>;
}

/// 后端类型
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BackendType {
    Etcd,
    Consul,
    Mesh,
}

impl BackendType {
    pub fn from_str(s: &str) -> Self {
        match s.to_lowercase().as_str() {
            "consul" => BackendType::Consul,
            "mesh" => BackendType::Mesh,
            _ => BackendType::Etcd,
        }
    }
}

/// 创建后端实例
pub async fn create_backend(
    config: RegistryConfig,
) -> Result<Box<dyn Backend>, Box<dyn std::error::Error>> {
    let backend_type = BackendType::from_str(&config.registry_type);

    match backend_type {
        BackendType::Etcd => {
            let backend = etcd::EtcdBackend::new(
                config.endpoints.clone(),
                config.namespace.clone(),
                config.ttl,
            )
            .await?;
            Ok(Box::new(backend))
        }
        BackendType::Consul => {
            let backend = consul::ConsulBackend::new(
                config.endpoints.clone(),
                config.namespace.clone(),
                config.ttl,
            )
            .await?;
            Ok(Box::new(backend))
        }
        BackendType::Mesh => {
            let backend = mesh::MeshBackend::new(config.namespace.clone()).await?;
            Ok(Box::new(backend))
        }
    }
}

/// 后端构建器
pub struct BackendBuilder {
    config: Option<RegistryConfig>,
}

impl BackendBuilder {
    pub fn new() -> Self {
        Self { config: None }
    }

    pub fn with_config(mut self, config: RegistryConfig) -> Self {
        self.config = Some(config);
        self
    }

    pub async fn build(self) -> Result<Box<dyn Backend>, Box<dyn std::error::Error>> {
        let config = self.config.ok_or("Registry config is required")?;
        create_backend(config).await
    }
}

impl Default for BackendBuilder {
    fn default() -> Self {
        Self::new()
    }
}

