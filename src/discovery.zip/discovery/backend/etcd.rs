//! etcd 后端实现

use crate::discovery::backend::Backend;
use crate::discovery::instance::Instance;
use async_trait::async_trait;
use etcd_client::{Client, PutOptions};
use std::sync::Arc;
use std::time::Duration;
use tracing::{error, info};

/// etcd 后端实现
pub struct EtcdBackend {
    client: Client,
    namespace: String,
    ttl: u64,
    lease_id: Option<i64>,
    keep_alive_handle: Option<tokio::task::JoinHandle<()>>,
    health_check_handle: Option<tokio::task::JoinHandle<()>>,
}

impl EtcdBackend {
    pub async fn new(
        etcd_endpoints: Vec<String>,
        namespace: String,
        ttl: u64,
    ) -> Result<Self, Box<dyn std::error::Error>> {
        let client = Client::connect(etcd_endpoints, None)
            .await
            .map_err(|e| format!("Failed to connect to etcd: {}", e))?;

        Ok(Self {
            client,
            namespace,
            ttl,
            lease_id: None,
            keep_alive_handle: None,
            health_check_handle: None,
        })
    }

    async fn start_keep_alive_internal(&mut self, lease_id: i64) {
        let mut client = self.client.clone();
        let ttl = self.ttl as i64;

        let handle = tokio::spawn(async move {
            loop {
                tokio::time::sleep(Duration::from_secs(ttl as u64 / 3)).await;

                match client.lease_keep_alive(lease_id).await {
                    Ok((_keeper, mut stream)) => {
                        use tokio_stream::StreamExt;
                        while let Some(resp) = stream.next().await {
                            match resp {
                                Ok(_resp) => {
                                    // Keep-alive successful
                                }
                                Err(e) => {
                                    error!("Lease keep-alive stream error: {}", e);
                                    break;
                                }
                            }
                        }
                    }
                    Err(e) => {
                        error!("Lease keep-alive failed: {}", e);
                        break;
                    }
                }
            }
        });

        self.keep_alive_handle = Some(handle);
    }
}

#[async_trait]
impl Backend for EtcdBackend {
    async fn register(&mut self, instance: Arc<Instance>) -> Result<(), Box<dyn std::error::Error>> {
        let lease = self
            .client
            .lease_grant(self.ttl as i64, None)
            .await
            .map_err(|e| format!("Failed to grant lease: {}", e))?;

        let lease_id = lease.id();
        self.lease_id = Some(lease_id);

        let key = format!(
            "/{}/{}/{}",
            self.namespace, instance.service_type, instance.instance_id
        );

        let value = serde_json::to_string(&*instance)
            .map_err(|e| format!("Failed to serialize instance: {}", e))?;

        let mut opts = PutOptions::new();
        opts = opts.with_lease(lease_id);

        self.client
            .put(key.clone(), value, Some(opts))
            .await
            .map_err(|e| format!("Failed to register service: {}", e))?;

        info!(
            "Service registered: {} at {}",
            instance.instance_id, instance.address
        );

        self.start_keep_alive_internal(lease_id).await;

        Ok(())
    }

    async fn unregister(&mut self, instance_id: &str) -> Result<(), Box<dyn std::error::Error>> {
        // 停止 keep-alive
        if let Some(handle) = self.keep_alive_handle.take() {
            handle.abort();
        }

        // 删除服务
        let key_prefix = format!("/{}/", self.namespace);
        let mut client = self.client.clone();
        let resp = client
            .get(key_prefix.clone(), None)
            .await
            .map_err(|e| format!("Failed to discover services: {}", e))?;

        for kv in resp.kvs() {
            if let Ok(instance) = serde_json::from_slice::<Instance>(kv.value()) {
                if instance.instance_id == instance_id {
                    let key = String::from_utf8_lossy(kv.key());
                    client
                        .delete(key.to_string(), None)
                        .await
                        .map_err(|e| format!("Failed to unregister service: {}", e))?;
                    info!("Service unregistered: {}", instance_id);
                    break;
                }
            }
        }

        Ok(())
    }

    async fn discover(&self, service_type: &str) -> Result<Vec<Arc<Instance>>, Box<dyn std::error::Error>> {
        let key_prefix = format!("/{}/{}/", self.namespace, service_type);

        let mut client = self.client.clone();
        let resp = client
            .get(key_prefix.clone(), None)
            .await
            .map_err(|e| format!("Failed to discover services: {}", e))?;

        let mut instances = Vec::new();
        for kv in resp.kvs() {
            if let Ok(instance) = serde_json::from_slice::<Instance>(kv.value()) {
                instances.push(Arc::new(instance));
            }
        }

        Ok(instances)
    }

    async fn list_service_types(&self) -> Result<Vec<String>, Box<dyn std::error::Error>> {
        let key_prefix = format!("/{}/", self.namespace);
        let mut client = self.client.clone();
        let resp = client
            .get(key_prefix.clone(), None)
            .await
            .map_err(|e| format!("Failed to list service types: {}", e))?;

        let mut service_types = std::collections::HashSet::new();
        for kv in resp.kvs() {
            if let Ok(instance) = serde_json::from_slice::<Instance>(kv.value()) {
                service_types.insert(instance.service_type);
            }
        }

        Ok(service_types.into_iter().collect())
    }

    async fn list_all_instances(&self) -> Result<Vec<Arc<Instance>>, Box<dyn std::error::Error>> {
        let key_prefix = format!("/{}/", self.namespace);
        let mut client = self.client.clone();
        let resp = client
            .get(key_prefix.clone(), None)
            .await
            .map_err(|e| format!("Failed to list all instances: {}", e))?;

        let mut instances = Vec::new();
        for kv in resp.kvs() {
            if let Ok(instance) = serde_json::from_slice::<Instance>(kv.value()) {
                instances.push(Arc::new(instance));
            }
        }

        Ok(instances)
    }

    async fn health_check(&self) -> Result<(), Box<dyn std::error::Error>> {
        // etcd 健康检查：尝试获取一个 key
        let mut client = self.client.clone();
        let _ = client.get("/health", None).await
            .map_err(|e| format!("etcd health check failed: {}", e))?;
        Ok(())
    }

    fn start_health_check(&mut self, interval: Duration) -> Result<(), Box<dyn std::error::Error>> {
        let mut client = self.client.clone();
        let namespace = self.namespace.clone();
        
        let handle = tokio::spawn(async move {
            let mut interval = tokio::time::interval(interval);
            loop {
                interval.tick().await;
                
                // 检查所有服务实例的健康状态
                let key_prefix = format!("/{}/", namespace);
                if let Ok(resp) = client.get(key_prefix.clone(), None).await {
                    for kv in resp.kvs() {
                        if let Ok(mut instance) = serde_json::from_slice::<Instance>(kv.value()) {
                            // 简单的健康检查：检查实例是否还在 etcd 中
                            // 实际应用中可以通过 gRPC 健康检查端点检查
                            let instance_key = format!("{}/{}", key_prefix, instance.instance_id);
                            match client.get(instance_key, None).await {
                                Ok(_) => {
                                    instance.update_health(true);
                                }
                                Err(_) => {
                                    instance.update_health(false);
                                }
                            }
                        }
                    }
                }
            }
        });

        self.health_check_handle = Some(handle);
        Ok(())
    }

    fn stop_health_check(&mut self) -> Result<(), Box<dyn std::error::Error>> {
        if let Some(handle) = self.health_check_handle.take() {
            handle.abort();
        }
        Ok(())
    }
}

